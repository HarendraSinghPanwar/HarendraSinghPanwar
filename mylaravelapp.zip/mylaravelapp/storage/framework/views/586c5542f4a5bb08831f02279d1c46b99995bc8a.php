<?php $__env->startSection('content'); ?>
	  <!-- You are: (shop domain name) -->
	  <p>You are: <?php echo e(Auth::user()->name); ?></p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	 <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
	<script type="text/javascript">
	    var AppBridge = window['app-bridge'];
	    var actions = AppBridge.actions;
	    var TitleBar = actions.TitleBar;
      var Button = actions.Button;
	    var Redirect = actions.Redirect;
	    var titleBarOptions = {
		title: 'Welcome',
        };
        var myTitleBar = TitleBar.create(app, titleBarOptions);
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mylaravelapp/resources/views/welcome.blade.php ENDPATH**/ ?>