<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
 

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

        
        public function index() {
            $shop = Auth::user();

            // dd($shop);
            $domain = $shop->getDomain()->toNative();
            // dd($domain );
            $shopApi = $shop->api()->rest('GET', '/admin/api/2022-10/customers.json')['body'];
            $data = json_decode(json_encode($shopApi), true);
            dd( $data);
    
        //     $shop = Auth::user();

        // $domain = $shop->getDomain()->toNative();
        // $shopApi = $shop->api()->rest('GET', '/admin/api/2023-01/customers.json')['body'];


        // $data = json_decode(json_encode($shopApi), true);
        // dd( $data);
        

    //    dd($data['customers']);
           
    }
}

